# Black Russia AI Assistant — prototype source

This is an Android Studio starter project for a user-consented screen-capture OCR prototype. It is **not a finished APK** and has not been compiled or tested on a device.

## Current prototype scope
- User explicitly starts Android MediaProjection screen capture.
- A visible foreground-service notification remains while capture is active.
- Google ML Kit Text Recognition reads captured screen text.
- A small local answer engine recognizes basic arithmetic and a starter set of capital-city questions.
- Answers appear as Android notifications. Sound and vibration are disabled.
- It does not tap, type into, or send anything in the game.

## Build
Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support), allow Gradle sync, then Build > Build APK(s).

## Important limitations / next steps
- The OCR currently analyzes full-screen frames; it needs chat-region cropping and throttling before practical use.
- Android requires a visible MediaProjection consent prompt and ongoing foreground notification. Capture may be blocked by secure-screen flags and can stop when Android revokes the projection.
- Android 14+ has stricter MediaProjection lifecycle rules. Test on the target Android version and adapt the service lifecycle as needed.
- Notification permission may be required on Android 13+.
- The app does not auto-fill game chat. That would require a separate, user-enabled accessibility workflow and compatibility testing; the user must remain in control of sending.
- This is an independent helper prototype, not integrated into or endorsed by Black Russia.
